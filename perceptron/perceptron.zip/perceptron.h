#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <math.h>
#include <string.h>

typedef struct {
	float value;
	float *weight;
} Neuron;
